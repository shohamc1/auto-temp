# auto-temp
Tired of updating temperature? This automates it for you!
Please only use if you are sure that you are fine.

### How to use

 - Install Python 3
 - Install dependencies from ``requirements.txt``, run ``py -m pip install -r requirements.txt``
 - Edit info_example.json with your details and rename to info.json
 - Run ``python main.pyw``